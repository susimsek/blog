import { render, screen } from '@testing-library/react';
import LanguageSwitcher from '@/components/i18n/LanguageSwitcher';
import LanguageSwitchLink from '@/components/i18n/LanguageSwitchLink';

jest.mock('next/navigation', () => ({
  useRouter: () => ({ replace: jest.fn() }),
  usePathname: () => '/en',
  useSearchParams: () => new URLSearchParams(),
  useParams: () => ({ locale: 'en' }),
}));

// Mocking react-i18next and FontAwesomeIcon
jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (key: string) => key }),
}));

jest.mock('@fortawesome/react-fontawesome', () => ({
  FontAwesomeIcon: ({ icon, className }: { icon: string; className?: string }) => (
    <i data-testid={`font-awesome-icon-${icon}`} className={className} />
  ),
}));

jest.mock('@/components/common/FlagIcon', () => {
  return ({ code, alt }: { code: string; alt?: string }) => <span data-testid={`flag-${code}`} aria-label={alt}></span>;
});

describe('LanguageSwitcher', () => {
  it('renders the globe icon correctly', () => {
    render(<LanguageSwitcher />);

    // Select the icon using the mocked data-testid
    const globeIcon = screen.getByTestId('font-awesome-icon-globe');
    expect(globeIcon).toBeInTheDocument();
  });

  it('renders the language switcher dropdown', () => {
    render(<LanguageSwitcher />);

    // Ensure the dropdown is in the document
    const dropdown = screen.getByRole('button', { name: /common.language/i });
    expect(dropdown).toBeInTheDocument();
  });

  it('uses the current locale from router.query when available', () => {
    render(<LanguageSwitcher />);

    // Verify the correct locale is used (in this case, fr-FR)
    const dropdown = screen.getByRole('button', { name: /common.language/i });
    expect(dropdown).toHaveTextContent('common.language'); // Assuming the default text content is 'common.language'
  });

  it('uses the default locale when router.query.locale is not available', () => {
    render(<LanguageSwitcher />);

    // Verify the correct default locale is used
    const dropdown = screen.getByRole('button', { name: /common.language/i });
    expect(dropdown).toHaveTextContent('common.language'); // Assuming the default text content is 'common.language'
  });

  it('renders the locale code as fallback when no display name is available', () => {
    render(<LanguageSwitchLink locale="es" />);
    const button = screen.getByRole('button');
    expect(button).toHaveTextContent('es');
  });

  it('renders the display name for the locale when available in localeNames', () => {
    render(<LanguageSwitchLink locale="tr" />);
    const button = screen.getByRole('button');
    expect(button).toHaveTextContent('Türkçe');
  });

  it('renders boop classes on language icon wrapper', () => {
    render(<LanguageSwitcher />);

    expect(screen.getByTestId('font-awesome-icon-globe').parentElement).toHaveClass('nav-icon-boop');
    expect(screen.getByTestId('font-awesome-icon-globe')).toHaveClass('icon-boop-target');
  });
});
