import React from 'react';
import { render, screen } from '@testing-library/react';
import SearchRoute, { generateMetadata } from '@/app/(localized)/[locale]/search/page';

const getServerTranslatorMock = jest.fn(async (_locale: string, _ns: string[]) => ({
  t: (key: string) =>
    ({
      'search.title': 'Search Title',
      'search.meta.description': 'Search Description',
      'search.meta.keywords': 'search,meta,keywords',
    })[key] ?? key,
}));
const loadLocaleResourcesMock = jest.fn(async (_locale: string, _ns: string[]) => ({
  search: { search: { title: 'Search' } },
}));

const getAllTopicsMock = jest.fn(async (_locale: string) => [{ id: 'topic-1' }]);
const searchPageMock = jest.fn((_props: { topics: unknown[] }) => <div data-testid="search-page">search-page</div>);

jest.mock('@/i18n/server', () => ({
  getServerTranslator: (locale: string, ns: string[]) => getServerTranslatorMock(locale, ns),
  loadLocaleResources: (locale: string, ns: string[]) => loadLocaleResourcesMock(locale, ns),
}));

jest.mock('@/i18n/RouteI18nProvider', () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

jest.mock('@/lib/posts', () => ({
  getAllTopics: (locale: string) => getAllTopicsMock(locale),
}));

jest.mock('@/views/SearchPage', () => ({
  __esModule: true,
  default: (props: { topics: unknown[] }) => searchPageMock(props),
}));

describe('App Route /[locale]/search', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('builds metadata with noindex robots', async () => {
    const metadata = await generateMetadata({
      params: Promise.resolve({ locale: 'en' }),
      searchParams: Promise.resolve({}),
    });

    expect(metadata).toMatchObject({
      title: 'Search Title',
      description: 'Search Description',
      keywords: 'search,meta,keywords',
      robots: {
        index: false,
        follow: true,
      },
    });
  });

  it('loads search data and renders SearchPage view', async () => {
    const element = await SearchRoute({
      params: Promise.resolve({ locale: 'tr' }),
      searchParams: Promise.resolve({}),
    });
    render(element);

    expect(getAllTopicsMock).toHaveBeenCalledWith('tr');
    expect(loadLocaleResourcesMock).toHaveBeenCalledWith('tr', ['search']);
    expect(searchPageMock).toHaveBeenCalledWith({
      topics: [{ id: 'topic-1' }],
    });
    expect(screen.getByTestId('search-page')).toBeInTheDocument();
  });
});
