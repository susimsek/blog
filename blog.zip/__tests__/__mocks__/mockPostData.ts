import { PostSummary, Post, Topic } from '@/types/posts';

export const mockTopic: Topic = {
  id: 'react',
  name: 'React',
  color: 'red',
};

export const mockPost: Post = {
  id: '1',
  title: 'Test Post',
  date: '2024-12-03',
  source: 'blog',
  contentHtml: '<p>Test Content</p>',
  readingTimeMin: 3,
  searchText: 'test post test summary react testing',
  thumbnail: '/test-thumbnail.jpg',
  topics: [mockTopic, { id: 'testing', name: 'Testing', color: 'green' }],
  summary: 'Test summary',
};

export const mockPost2: Post = {
  id: '1',
  title: 'Another Test Post',
  date: '2024-12-03',
  source: 'blog',
  contentHtml: '<p>Another Test Content</p>',
  readingTimeMin: 3,
  searchText: 'another test post another test summary react testing',
  thumbnail: '/test-thumbnail.jpg',
  topics: [mockTopic, { id: 'testing', name: 'Testing', color: 'green' }],
  summary: 'Another Test summary',
};

export const mockPostSummary: PostSummary = {
  id: '1',
  title: 'Test Post',
  date: '2024-12-03',
  source: 'blog',
  thumbnail: '/test-thumbnail.jpg',
  readingTimeMin: 3,
  searchText: 'test post test summary react testing',
  topics: [mockTopic, { id: 'testing', name: 'Testing', color: 'green' }],
  summary: 'Test summary',
};

export const mockPostWithoutContent: Post = {
  ...mockPost,
  contentHtml: undefined,
};

export const mockPosts: Post[] = [mockPost, mockPost2];

export const mockTopicVue: Topic = {
  id: 'vue',
  name: 'Vue.js',
  color: 'purple',
};

export const mockTopics: Topic[] = [mockTopic, mockTopicVue];

export const mockPostSummaries: PostSummary[] = [
  {
    id: '1',
    title: 'Post 1',
    summary: 'Summary 1',
    date: '2024-12-03',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 1 summary 1 react testing',
    topics: [mockTopic, { id: 'testing', name: 'Testing', color: 'green' }],
  },
  {
    id: '2',
    title: 'Post 2',
    summary: 'Summary 2',
    date: '2023-11-03',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 2 summary 2',
  },
  {
    id: '3',
    title: 'Post 3',
    summary: 'Summary 3',
    date: '2023-10-01',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 3 summary 3',
  },
  {
    id: '4',
    title: 'Post 4',
    summary: 'Summary 4',
    date: '2023-09-15',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 4 summary 4',
  },
  {
    id: '5',
    title: 'Post 5',
    summary: 'Summary 5',
    date: '2023-08-20',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 5 summary 5',
  },
  {
    id: '6',
    title: 'Post 6',
    summary: 'Summary 6',
    date: '2023-07-10',
    source: 'blog',
    thumbnail: null,
    readingTimeMin: 3,
    searchText: 'post 6 summary 6',
  },
];

export const mockTopicIds: { params: { id: string; locale: string } }[] = [
  {
    params: {
      id: 'react',
      locale: 'en',
    },
  },
  {
    params: {
      id: 'react',
      locale: 'fr',
    },
  },
  {
    params: {
      id: 'react',
      locale: 'de',
    },
  },
  {
    params: {
      id: 'testing',
      locale: 'en',
    },
  },
  {
    params: {
      id: 'testing',
      locale: 'fr',
    },
  },
  {
    params: {
      id: 'testing',
      locale: 'de',
    },
  },
];
