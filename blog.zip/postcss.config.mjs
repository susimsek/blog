/** @type {import('postcss-load-config').Config} */
const config = {
  plugins: {
    autoprefixer: {},
  },
};

export default config;
