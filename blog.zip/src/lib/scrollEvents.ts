export const BACK_TO_TOP_EVENT = 'blog:back-to-top';
