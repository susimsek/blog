// scripts/strip-reading-time.js
// Removes "readingTime" from public/data/posts.<locale>.json entries.

const fs = require('node:fs');
const path = require('node:path');

const locales = ['en', 'tr'];

const readJson = filePath => JSON.parse(fs.readFileSync(filePath, 'utf8'));

const writeJson = (filePath, value) => {
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + '\n', 'utf8');
};

for (const locale of locales) {
  const postsPath = path.join(process.cwd(), 'public', 'data', `posts.${locale}.json`);
  const posts = readJson(postsPath);

  let changed = 0;
  const next = posts.map(post => {
    if (!Object.prototype.hasOwnProperty.call(post, 'readingTime')) {
      return post;
    }
    const { readingTime, ...rest } = post;
    void readingTime;
    changed += 1;
    return rest;
  });

  writeJson(postsPath, next);
  console.log(`[strip-reading-time] locale=${locale} changedPosts=${changed} -> ${postsPath}`);
}
